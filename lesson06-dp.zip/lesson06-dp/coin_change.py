"""凑硬币：贪心与动态规划，仅使用标准库。"""
def validate(coins, amount):
    if type(amount) is not int or amount < 0:
        raise ValueError("金额必须是非负整数")
    if any(type(c) is not int or c <= 0 for c in coins):
        raise ValueError("面额必须是正整数")
    return sorted(set(coins))


def coin_greedy(coins, amount):
    coins = validate(coins, amount)
    chosen = []
    for coin in reversed(coins):
        count, amount = divmod(amount, coin)
        chosen.extend([coin] * count)
    return (-1, []) if amount else (len(chosen), chosen)


def coin_dp(coins, amount):
    coins = validate(coins, amount)
    dp = [0] + [float("inf")] * amount
    last = [0] * (amount + 1)
    for c in range(1, amount + 1):
        for coin in coins:
            if coin <= c and dp[c - coin] + 1 < dp[c]:
                dp[c] = dp[c - coin] + 1  # 核心填表：枚举最后一枚硬币
                last[c] = coin
    if dp[amount] == float("inf"):
        return -1, []
    chosen, c = [], amount
    while c:
        chosen.append(last[c])
        c -= last[c]
    return dp[amount], chosen


if __name__ == "__main__":
    print("贪心：", coin_greedy([1, 5, 11], 15))
    print("动态规划：", coin_dp([1, 5, 11], 15))
