# lesson06-dp

第6次课：贪心与动态规划。Python 3，无第三方依赖。

```sh
python coin_change.py
python knapsack.py
python verify.py
```

- `progress.md`：按老师模板整理的报告、独立研究和AI使用记录。
- `coin_change.py`、`knapsack.py`：算法及变体。
- `items.json`：按课堂幻灯片录入的教学演示虚构数据；原始要求文档未改动。
- `results.json`、`dp_last_row.csv`、`verification.txt`：实际计算与核验结果。
- `作答区.txt`：直接填写的简述。

代码由本次AI协作生成，未复制同学代码或身份信息。姓名：宋昶辉；学号：20251030008。
