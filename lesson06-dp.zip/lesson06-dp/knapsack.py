"""0-1 背包：至多装满；容量按 1 克计算，避免舍入误差。"""
import json
from pathlib import Path

ITEMS = json.loads((Path(__file__).parent / "items.json").read_text(encoding="utf-8"))


def knapsack(items, capacity):
    if type(capacity) is not int or capacity < 0:
        raise ValueError("容量必须是非负整数")
    n = len(items)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    for i, item in enumerate(items, 1):
        w, v = item["weight"], item["value"]
        for c in range(capacity + 1):
            dp[i][c] = dp[i - 1][c]
            if c >= w:
                dp[i][c] = max(dp[i - 1][c], dp[i - 1][c - w] + v)
    chosen, trace, c = [], [], capacity
    for i in range(n, 0, -1):
        take = dp[i][c] > dp[i - 1][c]
        next_c = c - items[i - 1]["weight"] if take else c
        trace.append(f"({i},{c}) → ({i-1},{next_c})：{'选' if take else '不选'}物品{items[i-1]['id']}")
        if take:
            chosen.append(items[i - 1]["id"])
        c = next_c
    return dp[n][capacity], sorted(chosen), dp, trace


def mandatory_knapsack(items, capacity, required):
    required = set(required)
    if not required <= {x["id"] for x in items}:
        raise ValueError("必选物品不存在")
    fixed = [x for x in items if x["id"] in required]
    remaining = capacity - sum(x["weight"] for x in fixed)
    if remaining < 0:
        return None, []
    value, chosen, _, _ = knapsack([x for x in items if x["id"] not in required], remaining)
    return value + sum(x["value"] for x in fixed), sorted(chosen + list(required))


def complete_knapsack(items, capacity):
    dp = [0] * (capacity + 1)
    for item in items:
        w, v = item["weight"], item["value"]
        for c in range(w, capacity + 1):  # 正序允许重复选取；0-1 一维写法须逆序
            dp[c] = max(dp[c], dp[c - w] + v)
    return dp[capacity]


if __name__ == "__main__":
    for capacity in (1000, 800):
        value, chosen, _, trace = knapsack(ITEMS, capacity)
        print(f"容量{capacity}：重要度{value}，组合{chosen}")
        print("\n".join(trace))
        print("必选帐篷：", mandatory_knapsack(ITEMS, capacity, [1]))
