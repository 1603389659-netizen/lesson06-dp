"""用独立穷举核验全部容量以及边界条件。"""
from itertools import product
from coin_change import coin_greedy, coin_dp
from knapsack import ITEMS, knapsack, mandatory_knapsack, complete_knapsack


def brute(capacity, required=()):
    values = []
    for bits in product((0, 1), repeat=len(ITEMS)):
        chosen = [x for x, b in zip(ITEMS, bits) if b]
        ids = {x["id"] for x in chosen}
        if set(required) <= ids and sum(x["weight"] for x in chosen) <= capacity:
            values.append(sum(x["value"] for x in chosen))
    return max(values) if values else None


def verify():
    _, _, table, _ = knapsack(ITEMS, 1000)
    for c in range(1001):
        assert table[-1][c] == brute(c)
    for c in (0, 299, 300, 800, 1000):
        value, ids = mandatory_knapsack(ITEMS, c, [1])
        assert value == brute(c, [1])
        if value is not None:
            selected = [x for x in ITEMS if x["id"] in ids]
            assert 1 in ids and sum(x["weight"] for x in selected) <= c
            assert sum(x["value"] for x in selected) == value
    assert coin_greedy([1,5,11],15) == (5,[11,1,1,1,1])
    assert coin_dp([1,5,11],15) == (3,[5,5,5])
    assert coin_dp([2],3) == (-1,[])
    assert coin_dp([],0) == (0,[])
    assert coin_greedy([3,4],6) == (-1,[])
    assert coin_dp([3,4],6) == (2,[3,3])
    assert knapsack([],0)[0] == 0
    assert complete_knapsack([{"weight":2,"value":3}],6) == 9
    print("通过：1001 个容量与 32 种子集穷举一致；必选约束、硬币反例及边界检查通过。")


if __name__ == "__main__":
    verify()
